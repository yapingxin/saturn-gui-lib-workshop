/* #undef HAVE_X11_EXTENSIONS_XF86VMODE_H */
/* #undef HAVE_X11_EXTENSIONS_XRANDR_H */
/* #undef HAVE_X11_EXTENSIONS_XINPUT2_H */
#define HAVE_SYS_TYPES_H
/* #undef HAVE_UNISTD_H */
/* #undef HAVE_SYS_TIME_H */
#define HAVE_STDBOOL_H
/* #undef HAVE_SYS_PARAM_H */
/* #undef HAVE_SYS_IOCTL_H */
#define HAVE_FCNTL_H
/* #undef HAVE_ERRNO_H */
/* #undef HAVE_USBHID_H */
/* #undef HAVE_GETTIMEOFDAY */
/* #undef HAVE_VFPRINTF */
/* #undef HAVE_DOPRNT */
#define NEED_XPARSEGEOMETRY_IMPL
#define HAVE_STDINT_H
#define HAVE_INTTYPES_H
/* #undef HAVE_ULONG_LONG */
/* #undef HAVE_U__INT64 */

/* warning and errors printed? */
#define FREEGLUT_PRINT_WARNINGS
#define FREEGLUT_PRINT_ERRORS
